# -*- coding: utf-8 -*-
# SPDX-License-Identifier: GPL-2.0-or-later
"""Right-click script (see ctxutil.py)."""

import ctxutil

if __name__ == "__main__":
    ctxutil.run_plugin(action="add_movies", bid=ctxutil.current_bid())
